<?php
header('location: /');

?>